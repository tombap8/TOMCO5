// 보그 PJ 공통 기능 JS - common.js

